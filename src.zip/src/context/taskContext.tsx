

import React, { createContext, useReducer, ReactNode } from 'react';
import { taskReducer } from '../reducers/taskReducer';

interface Task {
  id: string;
  title: string;
  completed: boolean;
}

interface TaskContextProps {
  tasks: Task[];
  dispatch: React.Dispatch<any>;
}

export const TaskContext = createContext<TaskContextProps | undefined>(undefined);

const initialTasks: Task[] = [];

export const TaskProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [tasks, dispatch] = useReducer(taskReducer, initialTasks);

  return (
    <TaskContext.Provider value={{ tasks, dispatch }}>
      {children}
    </TaskContext.Provider>
  );
};
